<?php
  require_once("init.php");

  if(isset($_POST["table"], $_POST["column"], $_POST["id"])) {
    $manager = PDOUtils::getSharedInstance();
    $data = $manager->getAll("SELECT idLanding, timetable FROM " . $_POST["table"] . " WHERE " . $_POST["column"] . " = ?", [$_POST["id"]]);
    
    foreach($data as $array) {
      echo utf8_encode(implode(":", $array)) . "\n";
    }
  }
?>
