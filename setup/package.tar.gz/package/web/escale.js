function choosePrestation(child) {
  let parent = document.querySelectorAll(".prestation");

  for(let p = 0; p < parent.length; p++) {
    parent[p].style.display = "none";
  }

  child.style.display = "";
}

document.querySelector("select").addEventListener("change", (e) => {
  let target = e.target;
  let table = target.selectedOptions[0].dataset.nexttable
  let type = target.value;
  let id = target.selectedOptions[0].dataset.id

  if(type !== "default") {
    console.log(table, type, id);
    loadTable(table, type, id);
  }
});

function loadTable(table, column, id) {
  if(column !== "default") {
    let request = new XMLHttpRequest();
    request.onreadystatechange = function(){
      if(request.readyState == 4 && request.status == 200){
        createOptions(table, request.responseText);
      }
    }

    request.open("POST", "loadTable.php");
    request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    request.send("table=" + table + "&column=" + column + "&id=" + id);
  }
}

function createOptions(table, content) {
  let options = content.split("\n");
  options.splice(options.length - 1, 1); // supprimer la case vide à la fin du tableau
  
  let selectDom = document.querySelector("#category select");
  let selectDomChildren = selectDom.options;
  for(let o = 0, selectDomLength = selectDomChildren.length; o < selectDomLength; o++) {
    selectDom.removeChild(selectDomChildren[0]); // supprimer les anciens options
  }

  let optionDom = document.createElement("option");
  optionDom.setAttribute("value", "default");
  optionDom.textContent = "Quelle période";
  selectDom.appendChild(optionDom);

  for(let option of options) {
    let values = option.split(":");
    let optionDom = document.createElement("option");

    optionDom.setAttribute("value", "default");
    optionDom.setAttribute("data-id", values[0]);
    optionDom.setAttribute("data-nexttable", "acoustic");
    optionDom.textContent = values[1];

    selectDom.appendChild(optionDom);
  }
}
