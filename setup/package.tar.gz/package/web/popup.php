<div onclick="return popup.manager.close(this);" class="cd-popup" role="alert">
	<div class="cd-popup-container">
		<p id="cd-popup-paragraph"></p>
	</div>
</div>