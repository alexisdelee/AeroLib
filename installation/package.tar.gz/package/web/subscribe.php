<?php
  session_start();

  require_once("class.LogPDO.php");
  require_once("class.user.php");

  if(isset($_POST["name"]) && isset($_POST["age"]) && isset($_POST["email"]) && isset($_POST["password"])) {
    $_POST["name"] = trim($_POST["name"]);
    $_POST["age"] = trim($_POST["age"]);
    $_POST["email"] = trim($_POST["email"]);

    unset($_SESSION["error_subscribe"]);

    $user = new User();
    $_SESSION["error_subscribe"][] = $user->stateEmail($_POST["email"]);
    $_SESSION["error_subscribe"][] = $user->stateName($_POST["name"]);
    $_SESSION["error_subscribe"][] = $user->stageAge($_POST["age"]);
  } else {
    echo "false";
  }

  if(empty(array_filter($_SESSION["error_subscribe"]))) {
    $_SESSION["accesstoken"] = md5(uniqid());

    $bdd = new LogPDO();
    $bdd->execute("INSERT INTO user(name, password, email, age, accesstoken) VALUES(?, ?, ?, ?, ?)", [utf8_decode($_POST["name"]), password_hash($_POST["password"], PASSWORD_DEFAULT), utf8_decode($_POST["email"]), $_POST["age"], $_SESSION["accesstoken"]]);

    /* $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=\"UTF-8\"" . "\r\n";
    $headers .= "From: <aerodrome.evreux.normandie.service@protonmail.com>\n";
    $headers .= "Reply-To: aerodrome.evreux.normandie.service@protonmail.com\n";
    mail($_POST["email"], "[Aérodrome Évreux Normandie] Validation inscription", "http://localhost/aerodrome/verifemailphp?accesstoken=" . $_SESSION["accesstoken"], $headers); */

    shell_exec("curl -s --user 'api:key-574498042b726734909d719af9fcb3ff' https://api.mailgun.net/v3/sandbox3fa628dca20c40289500f2300ae3f7db.mailgun.org/messages -F from='Mailgun Sandbox <postmaster@sandbox3fa628dca20c40289500f2300ae3f7db.mailgun.org>' -F to='Alexis Delée <" . $_POST["email"] . ">' -F subject='Hello Alexis Delée' -F text='Congratulations Alexis Delée, you just sent an email with Mailgun!  You are truly awesome!'");

    echo "true";
  } else {
    echo join(":", $_SESSION["error_subscribe"]);
  }
?>